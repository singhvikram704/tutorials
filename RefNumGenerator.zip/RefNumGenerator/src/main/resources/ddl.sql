BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE ' || 'reference_number cascade constraints';
EXCEPTION
   WHEN OTHERS THEN
      IF SQLCODE != -942 THEN
         RAISE;
      END IF;
END;

create table reference_number (
       id varchar2(255 char) not null,
        journeyid varchar2(255 char),
        journey_name varchar2(255 char),
        partner_code varchar2(255 char),
        primary key (id)
    );
    
BEGIN
  EXECUTE IMMEDIATE 'DROP SEQUENCE ' || 'fivedigitsequence';
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE != -2289 THEN
      RAISE;
    END IF;
END;

BEGIN
  EXECUTE IMMEDIATE 'DROP SEQUENCE ' || 'fourdigitsequence';
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE != -2289 THEN
      RAISE;
    END IF;
END;

create sequence fivedigitsequence start with 1 increment by  1 maxvalue 99999 CACHE 100;
create sequence fourdigitsequence start with 1 increment by  1 maxvalue 9999 CACHE 100;

BEGIN
    DBMS_SCHEDULER.CREATE_JOB (
            job_name => '"SYS"."RESET_INDEXES"',
            job_type => 'PLSQL_BLOCK',
            job_action => 'drop sequence fivedigitsequence;
drop sequence fourdigitsequence;
create sequence fivedigitsequence start with 1 increment by  1 maxvalue 99999 CACHE 100;
create sequence fourdigitsequence start with 1 increment by  1 maxvalue 9999 CACHE 100;',
            number_of_arguments => 0,
            start_date => NULL,
            repeat_interval => 'FREQ=DAILY;BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN',
            end_date => NULL,
            enabled => TRUE,
            auto_drop => FALSE,
            comments => 'Resets_Running_IndexNumbers');

         
     
 
    DBMS_SCHEDULER.SET_ATTRIBUTE( 
             name => '"SYS"."RESET_INDEXES"', 
             attribute => 'logging_level', value => DBMS_SCHEDULER.LOGGING_OFF);
      
  
    
    DBMS_SCHEDULER.enable(
             name => '"SYS"."RESET_INDEXES"');
END;
