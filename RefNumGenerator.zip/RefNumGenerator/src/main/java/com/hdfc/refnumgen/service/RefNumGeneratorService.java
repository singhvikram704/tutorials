package com.hdfc.refnumgen.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.hdfc.refnumgen.constant.LogConstant;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.hdfc.refnumgen.RefNumGeneratorApplication;
import com.hdfc.refnumgen.controller.RefNumRequest;
import com.hdfc.refnumgen.controller.RefNumResponse;
import com.hdfc.refnumgen.domain.ReferenceNumber;
import com.hdfc.refnumgen.repository.ReferenceNumberRepository;
import com.fasterxml.uuid.Generators;


@Service
public class RefNumGeneratorService{

	static final Logger log =
	        LoggerFactory.getLogger(RefNumGeneratorService.class);

	@Autowired
	private ReferenceNumberRepository referenceNumberRepository;
	
	@Autowired
    private Environment env;
	
	@PersistenceContext
	private EntityManager em;
	
	@Autowired
	private RequestValidatorService requestValidatorService;
	
	public RefNumResponse save(RefNumRequest refNumRequest) {
		log.info("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Entered RefNumberGeneratorService.save()",
				LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
				refNumRequest.getJourneyID());

		RefNumResponse response =  requestValidatorService.validate(refNumRequest);
		if(response.getStatus().equals("FAILURE")) {
			return response;
		}
		
		ReferenceNumber referenceNumber = new ReferenceNumber();
		String referenceNumberID = "";		
		String journeyName = refNumRequest.getJourneyName();		
		String sequenceName = env.getProperty(journeyName + ".refnum.sequence");		
		String strategyPattern = env.getProperty(journeyName + ".refnum.strategy");

		String[] pattern = strategyPattern.split(";");
		
		for (String part: pattern) {
			String[] construct = part.split(":");
			
			switch(construct[0]) {
			case "date":
				referenceNumberID += DateTimeFormatter.ofPattern(construct[1]).format(LocalDateTime.now());  
				break;
			case "delimiter":
				referenceNumberID += construct[1];
				break;
			case "sequence":
				String query = "select " + sequenceName + ".nextval from dual";
				BigDecimal seq = (BigDecimal) em.createNativeQuery(query).getSingleResult();
				referenceNumberID += String.format(construct[1], seq.longValue());
				break;
			case "lexical-sequence":
				query = "select " + sequenceName + ".nextval from dual";
				seq = (BigDecimal) em.createNativeQuery(query).getSingleResult();
				referenceNumberID += String.format(construct[1],Integer.toString(seq.intValue(), Character.MAX_RADIX)).toUpperCase();
				break;
			case "pad-char":
				referenceNumberID = referenceNumberID.replace(StringUtils.SPACE,construct[1] );
				break;
			case "payload":
				try {
					Object attributeValue = ObjectUtils.getFieldNamesAndValues(refNumRequest, false).get(construct[1]);
					referenceNumberID += attributeValue;
				} catch (IllegalArgumentException | IllegalAccessException e) {
					log.error("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, IllegalException in RefNumberGeneratorService.save()",
							LogConstant.SYSTEM_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
							refNumRequest.getJourneyID(), e);
				}
				break;
			case "uuid":
				switch(construct[1]) {
				case "1":   // UUID Version 1 - time-based
					referenceNumberID += Generators.timeBasedGenerator().generate();
					break;
				case "2":   // DCE Security(version 2)
					referenceNumberID += UUID.randomUUID();
					break;
				case "3":   // name-based(version 3)
					byte[] bs = {1, 2, 3};
					referenceNumberID += UUID.nameUUIDFromBytes(bs);
					break;
				case "4":   // randomly generated UUID(version 4)
					referenceNumberID += UUID.randomUUID();
					break;
				default :   // randomly generated UUID(version 4)
					referenceNumberID += UUID.randomUUID();
					break;
				}
				break;
			default:
				break;
			}			
		}
		
		
		referenceNumber.setId(referenceNumberID);
		referenceNumber.setJourneyID(refNumRequest.getJourneyID());
		referenceNumber.setJourneyName(refNumRequest.getJourneyName());
		referenceNumber.setPartnerCode(refNumRequest.getPartnerCode());
		
		try {
			ReferenceNumber res = referenceNumberRepository.save(referenceNumber);
			response.setReferenceNumber(StringUtils.deleteWhitespace(res.getId()));
			response.setStatus("SUCCESS");	
		}catch(Exception e) {
			response.setStatus("FAILURE");
			response.setErrorCode("REF0005");
			response.setErrorText(e.getMessage());
			log.error("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Exception in RefNumberGeneratorService.save(), request : {}, {}",
					LogConstant.SYSTEM_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
					refNumRequest.getJourneyID(), refNumRequest.toString(), e.getMessage());
		}

		log.info("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Exiting RefNumberGeneratorService.save()",
				LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
				refNumRequest.getJourneyID());
							
		return response;
	}


}
