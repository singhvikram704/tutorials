package com.hdfc.refnumgen.repository;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hdfc.refnumgen.domain.ReferenceNumber;

@Transactional
@Repository()
public interface ReferenceNumberRepository extends CrudRepository<ReferenceNumber, String>{

}
