package com.hdfc.refnumgen.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author nereddy
 *
 */
@Entity()
@Table(name = "REFERENCE_NUMBER")
public class ReferenceNumber{
	
	/**
	 * 
	 */
	@Id
	private String id;
	private String journeyName;
	private String journeyID;
	private String partnerCode;
	
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	public String getJourneyName() {
		return journeyName;
	}
	public void setJourneyName(String journeyName) {
		this.journeyName = journeyName;
	}
	public String getJourneyID() {
		return journeyID;
	}
	public void setJourneyID(String journeyID) {
		this.journeyID = journeyID;
	}
	public String getPartnerCode() {
		return partnerCode;
	}
	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}
	@Override
	public String toString() {
		return "ReferenceNumber [" + (id != null ? "id=" + id + ", " : "")
				+ (journeyName != null ? "journeyName=" + journeyName + ", " : "")
				+ (journeyID != null ? "journeyID=" + journeyID + ", " : "")
				+ (partnerCode != null ? "partnerCode=" + partnerCode : "") + "]";
	}
	
	
}
