package com.hdfc.refnumgen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RefNumGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
