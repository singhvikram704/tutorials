package com.hdfc.refnumgen.service;

import com.hdfc.refnumgen.constant.LogConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.hdfc.refnumgen.controller.RefNumRequest;
import com.hdfc.refnumgen.controller.RefNumResponse;

@Service
public class RequestValidatorService {
	
	static final Logger log = 
	        LoggerFactory.getLogger(RequestValidatorService.class);
	
	@Autowired
    private Environment env;
	
	public RefNumResponse validate(RefNumRequest refNumRequest) {
		RefNumResponse response =  new RefNumResponse();

		log.info("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Entered RequestValidatorService.validate()",
				LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
				refNumRequest.getJourneyID());

		response.setStatus("SUCCESS");
		response.setErrorCode("REF0000");
		
		String journeyName = refNumRequest.getJourneyName();
		if(journeyName == null) {
			response.setStatus("FAILURE");
			response.setErrorCode("REF0001");
			response.setErrorText("Journey Name is Mandatory");
			log.error("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Journey Name not available in the request: {}",
					LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
					refNumRequest.getJourneyID(), refNumRequest.toString());
			return response;
		}
		
		String sequenceName = env.getProperty(journeyName + ".refnum.sequence");
		if(sequenceName == null) {
			response.setStatus("FAILURE");
			response.setErrorCode("REF0002");
			response.setErrorText("Sequence is not configured for the Journey");
			log.error("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Sequence is not configured for the Journey: {}",
					LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
					refNumRequest.getJourneyID(), refNumRequest.toString());
			return response;
		}
		
		String strategyPattern = env.getProperty(journeyName + ".refnum.strategy");
		if(strategyPattern == null) {
			response.setStatus("FAILURE");
			response.setErrorCode("REF0003");
			response.setErrorText("Reference Number Strategy is not configured for the Journey");
			log.error("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Reference Number Strategy is not configured for the Journey: {}",
					LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
					refNumRequest.getJourneyID(), refNumRequest.toString());
			return response;
		}
		
		String[] pattern = strategyPattern.split(";");
		for (String part: pattern) {
			String[] construct = part.split(":");
			if (construct[0].equals("payload")) {
				Object attributeValue;
				try {
					attributeValue = ObjectUtils.getFieldNamesAndValues(refNumRequest, false).get(construct[1]);
					if (attributeValue == null) {
						response.setStatus("FAILURE");
						response.setErrorCode("REF0004");
						response.setErrorText("Reference Number Strategy requires the attribute : " + construct[1]);
						log.error("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Reference Number Strategy requires the attribute: {}" ,
								LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
								refNumRequest.getJourneyID(), construct[1] + refNumRequest.toString());
						return response;
					}
				} catch (IllegalArgumentException | IllegalAccessException e) {
					response.setStatus("FAILURE");
					response.setErrorCode("REF0006");
					response.setErrorText("Technical Error Occured. Reference Number Strategy requires the attribute : " + construct[1]);
					log.error("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Technical Error Occured. Reference Number Strategy requires the attribute: {}",
							LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
							refNumRequest.getJourneyID(), construct[1] + refNumRequest.toString());
					return response;
				}
				
			}
		}
		log.info("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Exiting RequestValidatorService.validate()",
				LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
				refNumRequest.getJourneyID());
		return response;	
	}
	
}
