package com.hdfc.refnumgen.service;

import com.hdfc.refnumgen.constant.LogConstant;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;

import com.hdfc.refnumgen.controller.RefNumberController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ObjectUtils {

	static final Logger log =
			LoggerFactory.getLogger(RefNumberController.class);

	private ObjectUtils() {
	}

	public static Map<String, Object> getFieldNamesAndValues(final Object obj, boolean publicOnly)
			throws IllegalArgumentException, IllegalAccessException {
		log.info("logType: {}, Event: {}, Entered ObjectUtils.getFieldNamesAndValues() >>>>",
				LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR);
		Class<? extends Object> c1 = obj.getClass();
		Map<String, Object> map = new HashMap<String, Object>();
		Field[] fields = c1.getDeclaredFields();
		for (int i = 0; i < fields.length; i++) {
			String name = fields[i].getName();
			if (publicOnly) {
				if (Modifier.isPublic(fields[i].getModifiers())) {
					Object value = fields[i].get(obj);
					map.put(name, value);
				}
			} else {
				fields[i].setAccessible(true);
				Object value = fields[i].get(obj);
				map.put(name, value);
			}
		}
		log.info("logType: {}, Event: {}, Exiting ObjectUtils.getFieldNamesAndValues() >>>>",
				LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR);
		return map;
	}
}