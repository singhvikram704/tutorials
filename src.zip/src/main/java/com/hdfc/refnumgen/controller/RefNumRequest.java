package com.hdfc.refnumgen.controller;


public class RefNumRequest {
	private String journeyID;
	private String journeyName;
	private String partnerCode;
	/**
	 * @return the journeyID
	 */
	public String getJourneyID() {
		return journeyID;
	}
	/**
	 * @param journeyID the journeyID to set
	 */
	public void setJourneyID(String journeyID) {
		this.journeyID = journeyID;
	}
	/**
	 * @return the journeyName
	 */
	public String getJourneyName() {
		return journeyName;
	}
	/**
	 * @param journeyName the journeyName to set
	 */
	public void setJourneyName(String journeyName) {
		this.journeyName = journeyName;
	}
	/**
	 * @return the partnerCode
	 */
	public String getPartnerCode() {
		return partnerCode;
	}
	/**
	 * @param partnerCode the partnerCode to set
	 */
	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}
	@Override
	public String toString() {
		return "RefNumRequest [" + (journeyID != null ? "journeyID=" + journeyID + ", " : "")
				+ (journeyName != null ? "journeyName=" + journeyName + ", " : "")
				+ (partnerCode != null ? "partnerCode=" + partnerCode : "") + "]";
	}
	
	
	
}
