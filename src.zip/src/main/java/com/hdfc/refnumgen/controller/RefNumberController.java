package com.hdfc.refnumgen.controller;

import javax.validation.Valid;

import com.hdfc.refnumgen.constant.LogConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hdfc.refnumgen.RefNumGeneratorApplication;
import com.hdfc.refnumgen.service.RefNumGeneratorService;

@RestController
public class RefNumberController {
	
	static final Logger log = 
	        LoggerFactory.getLogger(RefNumberController.class);
	
	private final RefNumGeneratorService refNumGeneratorService;

	public RefNumberController(RefNumGeneratorService refNumGeneratorService) {
		super();
		this.refNumGeneratorService = refNumGeneratorService;
	}
	
	 @PostMapping("/api/v1/refnum")
	 RefNumResponse referenceNumber(@Valid @RequestBody RefNumRequest refNumRequest) {
		 log.info("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Entered RefNumberController.referenceNumber() >>>>",
				 LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
				 refNumRequest.getJourneyID());
		 log.info("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Request: {}",
				 LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
				 refNumRequest.getJourneyID(), refNumRequest.toString());
		 RefNumResponse refNum = refNumGeneratorService.save(refNumRequest);

		 log.info("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Response: {}",
				 LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
				 refNumRequest.getJourneyID(), refNum.toString());
		 log.info("logType: {}, Event: {}, JourneyName: {}, JourneyID: {}, Exiting RefNumberController.referenceNumber() <<<<",
				 LogConstant.AUDIT_LEVEL, LogConstant.REF_NUM_GENERATOR, refNumRequest.getJourneyName(),
				 refNumRequest.getJourneyID());
		 return refNum;
	  }

}
