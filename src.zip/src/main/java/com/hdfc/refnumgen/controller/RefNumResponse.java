package com.hdfc.refnumgen.controller;

public class RefNumResponse {
	private String status;
	private String referenceNumber;
	private String errorCode;
	private String errorText;
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the referenceNumber
	 */
	public String getReferenceNumber() {
		return referenceNumber;
	}
	/**
	 * @param referenceNumber the referenceNumber to set
	 */
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}
	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * @return the errorText
	 */
	public String getErrorText() {
		return errorText;
	}
	/**
	 * @param errorText the errorText to set
	 */
	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}
	@Override
	public String toString() {
		return "RefNumResponse [" + (status != null ? "status=" + status + ", " : "")
				+ (referenceNumber != null ? "referenceNumber=" + referenceNumber + ", " : "")
				+ (errorCode != null ? "errorCode=" + errorCode + ", " : "")
				+ (errorText != null ? "errorText=" + errorText : "") + "]";
	}
	
	
	
	
	
}
