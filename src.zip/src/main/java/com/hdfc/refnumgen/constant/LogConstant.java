package com.hdfc.refnumgen.constant;

public final class LogConstant {

    public static final String AUDIT_LEVEL = "AUDIT";
    public static final String REF_NUM_GENERATOR = "REF_NUM_GENERATOR";
    public static final String SYSTEM_LEVEL = "SYSTEM";
}
